Add this jars to repository/components/libs folder


bam.logClient.logviewer-0.1.jar
cassandra-jdbc-1.1.1.wso2v1.jar
commons-validator-1.4.0.jar
json-simple-1.1.jar